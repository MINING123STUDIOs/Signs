Not real symbols only for artistic use e.g. in games or illusrations
CC-NC-SA-ND-BY MINING123STUDIOS
Source: Wikipedia.org
